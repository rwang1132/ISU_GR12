﻿using Microsoft.AspNetCore.Mvc;
using ISU_Website.Birds;


namespace ISU_Website.Controllers
{
    public class SiteController:Controller
    {
        protected readonly IWebHostEnvironment _hostingEnvironment;

        public SiteController(IWebHostEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }
        //function that defines what submit bird does. passes a bird object through and adds bird to the database
        public void SubmitBird(Bird birdModel)
        {
            Console.WriteLine("test");
            birdModel.Date = DateTime.Parse(birdModel.Date).ToString("MM-dd-yyyy");
            Run.data.Birds.Add(birdModel);
            Run.data.SaveChanges();
            Response.Redirect("localhost:7063/YourSightings");
        }
        //redirects to proper page
        public IActionResult YourSightingsPage()
        {
            var birds = from e in Run.data.Birds
                        orderby e.ID
                        select e;
            return View();
        }

        //Deletes bird using the bird id. 
        public void DeleteBird(int ID)
        {
            Run.data.Birds.Remove(Run.data.Birds.First(c => c.ID == ID));
            Run.data.SaveChanges();
            Response.Redirect("localhost:7063/YourSightingsPage");
        }
    }
}

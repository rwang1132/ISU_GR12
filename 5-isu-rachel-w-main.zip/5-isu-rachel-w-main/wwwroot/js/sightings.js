﻿function nextPage(page) {
    
}
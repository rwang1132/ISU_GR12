using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ISU_Website.Pages
{
    public class Sightings3Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}

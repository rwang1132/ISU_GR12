using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ISU_Website.Pages
{
    public class YourSightingsPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ISU_Website.Pages
{
    public class gameModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
